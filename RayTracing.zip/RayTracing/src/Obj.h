#pragma once
#include <iostream>
#include <fstream>
#include <string>

class Obj {
public:
	Obj(std::string filename) {
		std::cout << "start" << std::endl;
		std::string myText;

		// Read from the text file
		std::ifstream MyReadFile(filename);

		// Use a while loop together with the getline() function to read the file line by line
		while (getline(MyReadFile, myText)) {
			// Output the text from the file
			std::cout << myText << std::endl;
		}

		// Close the file
		MyReadFile.close();
	}
private:

};